#pragma once

namespace Teakra::Test {
bool GenerateTestCasesToFile(const char* path);
}
