From https://github.com/yhirose/cpp-httplib/commit/0a629d739127dcc5d828474a5aedae1f234687d3

MIT License

===

cpp-httplib

A C++11 header-only HTTP library.

It's extremely easy to setup. Just include httplib.h file in your code!

Inspired by Sinatra and express.

© 2017 Yuji Hirose

