var searchData=
[
  ['virtual_20allocator_0',['Virtual allocator',['../virtual_allocator.html',1,'index']]],
  ['vk_5famd_5fdevice_5fcoherent_5fmemory_1',['VK_AMD_device_coherent_memory',['../vk_amd_device_coherent_memory.html',1,'index']]],
  ['vk_5fext_5fmemory_5fpriority_2',['VK_EXT_memory_priority',['../vk_ext_memory_priority.html',1,'index']]],
  ['vk_5fkhr_5fdedicated_5fallocation_3',['VK_KHR_dedicated_allocation',['../vk_khr_dedicated_allocation.html',1,'index']]],
  ['vulkan_20memory_20allocator_4',['Vulkan Memory Allocator',['../index.html',1,'']]]
];
