---
name: "\U0001F5C3 Everything Else"
about: For questions and issues that do not fall in any of the other categories.
title: ''
labels: ''
assignees: ''

---

<!-- Describe your question and issue here. This space is meant to be used for general questions that are neither bugs nor feature requests. If you're looking for help or support, please post on the forum instead: https://forum.activitywatch.net/ -->


<!-- Checked checkbox should look like this: [x] -->
- [ ] I have searched the [issues](https://github.com/ActivityWatch/activitywatch/issues) of this repo and believe that this is not a duplicate.
- [ ] I have searched the [documentation](https://docs.activitywatch.net/en/latest/) and believe that my question is not covered.

## Issue
<!-- Now feel free to write your issue, but please be descriptive! Thanks again 🙌 ❤️ -->
