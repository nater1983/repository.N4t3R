## Tools for working with the Adreno Vulkan blob

blob-patcher.py is a script for generating adrenotools loadable drivers from an extracted ROM zip  
qtimapper-shim allows newer drivers to work on devices that lack support for the new mapper HAL
acc-shim allows for suppling arguments to the underlying LLVM-based shader compiler library


