#!/usr/bin/env bash
../../afl-2.52b/afl-gcc inihfuzz.c ../ini.c -o inihfuzz
