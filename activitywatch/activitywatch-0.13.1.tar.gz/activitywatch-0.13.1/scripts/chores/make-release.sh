#!/bin/bash

#
# We should create a release checklist to ensure releases are consistent.
#

# Create an annotated tag
#git tag -a $
