// SPDX-FileCopyrightText: Copyright (c) 2024 merryhime <https://mary.rs>
// SPDX-License-Identifier: MIT

#if defined(__ARM64__) || defined(__aarch64__) || defined(_M_ARM64)
#    define ON_ARM64
#endif
